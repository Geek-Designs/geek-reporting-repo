<?php
if (!defined('ABSPATH')) {
  exit;
}
/* ===== Admin Menu Options ===== */
add_action( 'admin_menu', 'gk_reporting_register_menu', 99 );
/* ===== Register Menu ===== */
function gk_reporting_register_menu() {
  /* ===== Call Options ===== */
  //add_action( 'admin_init', 'register_gk_reporting_options', 99 ); // register settings
  /* ===== Add Menu Pages ===== */
  add_menu_page( 
    'Geek Reporting', 
    'Geek Reporting', 
    'manage_options', 
    'gk-reporting', 
    'gk_reporting_options_page', 
    'dashicons-chart-line', 
    99 
  );
}
