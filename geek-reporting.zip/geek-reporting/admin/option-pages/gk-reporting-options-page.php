<?php
if (!defined('ABSPATH')) {
  exit;
}
add_filter('mce_buttons_2', 'gk_customize_tinymce_buttons');
add_filter('tiny_mce_before_init', 'gk_customize_tinymce_options');

function gk_reporting_options_page() {
  if (!current_user_can('manage_options') && !is_admin() ) {
    return;
  }
  
  $reporting_nonce  = wp_create_nonce('gk_reporting_nonce');
  $config           = new gk_report_config();
  $report_gen       = new gk_report_gen();

  /* == Save Options SUBMIT == */
  if (isset($_POST['submit']) && ($_POST['submit'] === 'save-reporting-config')) {
    if (!wp_verify_nonce($_POST['gk_reporting_nonce'], 'gk_reporting_nonce')) {
      error_log('gk_reporting_options_page(): Invalid nonce');
      return false;
    }
    process_config_form($_POST);
  }
  /* == Generate Report SUBMIT == */
  if(isset($_POST['submit']) && ($_POST['submit'] === 'generate-report')) {
    if (!wp_verify_nonce($_POST['gk_reporting_nonce'], 'gk_reporting_nonce')) {
      error_log('gk_reporting_options_page(): Invalid nonce');
      return false;
    }
    process_config_form($_POST);
    $scheduled = $config->get_config_by_key('scheduled');

    switch ($scheduled->config_value) {
      case 'weekly':
        $from_date = date('Y-m-d', strtotime('-7 days'));
        break;
      case 'monthly':
        $from_date = date('Y-m-d', strtotime('-1 month'));
        break;
      case 'quarterly':
        $from_date = date('Y-m-d', strtotime('-3 months'));
        break;
      default:
        $from_date = date('Y-m-d', strtotime('-1 day'));
        break;
    }
    
    $generate_report  = $report_gen->generate_report($from_date, 'now');
  }
  /* == Clear Transient SUBMIT == */
  if(isset($_POST['submit']) && ($_POST['submit'] === 'clear-transient')) {
    if (!wp_verify_nonce($_POST['gk_reporting_nonce'], 'gk_reporting_nonce')) {
      error_log('gk_reporting_options_page(): Invalid nonce');
      return false;
    }
    delete_transient('gk_report_sent');
  }

  /* == Get Config == */
  $client_logo      = $config->get_config_by_key('client_logo') ?? array();
  $client_name      = $config->get_config_by_key('client_name') ?? array();
  $client_emails    = $config->get_config_by_key('client_emails') ?? array();
  $bcc_emails       = $config->get_config_by_key('bcc_emails') ?? array();
  $generated_by     = $config->get_config_by_key('generated_by') ?? array();
  $generated_by     = $generated_by->config_value ?? 'Geek Design';
  $generated_email  = $config->get_config_by_key('generated_email') ?? array();
  $generated_email  = $generated_email->config_value ?? 'support@geek.design';
  $author_by        = $config->get_config_by_key('author_by') ?? 'Alex Clementson';
  $subject          = $config->get_config_by_key('subject') ?? array();
  $scheduled        = $config->get_config_by_key('scheduled') ?? array();
  $time_range       = $config->get_config_by_key('time_range') ?? array();
  $email_message    = $config->get_config_by_key('email_message') ?? array();
  $recommendations  = $config->get_config_by_key('recommendations') ?? array();

  $client_logo_src  = wp_get_attachment_image_src($client_logo->config_value, 'medium');
  
  $time_range       = json_decode($time_range->config_value);
  $start_time       = date('H:i', strtotime($time_range->start_time ?? '00:00'));
  $end_time         = date('H:i', strtotime($time_range->end_time ?? '06:00'));

  $email_message    = json_decode($email_message->config_value);
  $email_message    = str_replace('\&quot;', '', $email_message);
  $email_message    = wp_unslash($email_message);
  if (empty($email_message) || $email_message === '') {
    $email_message = 'Hello,

Please find attached your website report. If you have have any questions please get in touch.

Thanks

<span style="font-size: 24px;"><strong>Chris Nurney</strong></span>

<em>Developer</em>

[geek_logo]

tel: <a href="tel:01733 686 100">01733 686 100</a> | web: <a href="https://geek.design/">geek.design</a>

<span style="font-size: 12px;">This email message and any accompanying attachments may contain confidential or privileged information. If you are not the intended recipient, do not use, disseminate, distribute or copy this message or attachments. If you have received this message in error, please notify the sender and delete it. Any views expressed in this message are those of the sender, except where the sender expressly and with authority states them to be the views of Geek Designs. Geek Designs does not accept responsibility for changes made to this message</span>

<span style="font-size: 12px;">At Geek Designs, we are committed to fostering a respectful, inclusive, and professional workplace. We kindly ask that all communications reflect this commitment, as professionalism is expected in every interaction. Please note that we have a zero-tolerance policy for any form of unprofessional, abusive, derogatory language or behaviour directed toward our employees, and should your email be found to include such behaviour, this will not be responded to. Thank you for helping us create a positive environment for all.</span>

<span style="font-size: 12px;"><strong>Registered Office:</strong> 76 Papyrus Road, Werrington, Peterborough, PE4 5BH</span>';
  }

  $recommendations  = json_decode($recommendations->config_value);
  if (empty($recommendations)) {
    $recommendations = '<h3>Security Recommendations</h3><p>(SSL, Updates, etc.)</p>
<h3>Performance Enhancements</h3><p>(Caching, Minification, etc.)</p>
<h3>Potential Improvements</h3> <p>(SEO, UX, etc.)</p>';
  }

  /* == Get Data == */
  $users            = get_users();
  $schedule_options = array(
    'daily',
    'weekly',
    'monthly',
    'quarterly'
  );

  /* == Styles == */
  wp_enqueue_style('admin-gk-reporting-css');
  /* == Scripts == */
  wp_enqueue_media();
  wp_enqueue_script('admin-gk-reporting-media-uploader');
  
  ?>
  <div id="gk-reporting-config" class="wrap gk-reporting-config">
    <h1>Geek Reporting Options</h1>
    <section class="gk-reporting-status">
      <?php 
      $check_report_schedule = $report_gen->check_report_schedule();
      ?>
      <span class="info status"><?php echo $check_report_schedule; ?></span>
    </section>
    <form method="post" action="" enctype="multipart/form-data">
      <section class="gk-reporting-client">
        <h2>Client</h2>
        <input type="hidden" name="gk_reporting_nonce" value="<?php echo $reporting_nonce; ?>">
        <div id="logo-upload-group" class="input-group upload-group">
          <label for="client_logo">Client Logo <span>(H: 400px, W: 600px)</span></label>
          <input type="hidden" name="client_logo" class="image-id" value="<?php echo $client_logo->config_value; ?>" />
          <img src="<?php echo $client_logo_src[0]; ?>" alt="Client Logo" />
          <button type="button" class="button button-primary upload-image">Upload Image</button>
        </div>
        <div class="input-group">
          <label for="client_name">Client Name</label>
          <input type="text" name="client_name" id="client_name" value="<?php echo $client_name->config_value; ?>" />
        </div>
        <div class="input-group">
          <label for="client_emails">Client Emails <span>(Comma Separated)</span></label>
          <input type="text" name="client_emails" id="client_emails" value="<?php echo $client_emails->config_value; ?>" />
        </div>
        <div class="input-group">
          <label for="generated_by">Created By</label>
          <input type="text" name="generated_by" value="<?php echo $generated_by; ?>" />
        </div>
        <div class="input-group">
          <label for="generated_email">From Email</label>
          <input type="text" name="generated_email" value="<?php echo $generated_email; ?>" />
        </div>
        <div class="input-group">
          <label for="bcc_emails">BCC Emails <span>(Comma Separated)</span></label>
          <input type="text" name="bcc_emails" id="bcc_emails" value="<?php echo $bcc_emails->config_value; ?>" />
        </div>
      </section>
      <section class="gk-reporting-config">
        <h2>Configuration</h2>
        <div class="input-group">
          <label for="author_by">Author By</label>
          <input type="text" name="author_by" id="author_by" value="<?php echo $author_by->config_value; ?>" />
        </div>
        <div class="input-group">
          <label for="subject">Subject</label>
          <input type="text" name="subject" id="subject" value="<?php echo $subject->config_value; ?>" />
        </div>
        <div class="input-group">
          <label for="scheduled">Scheduled</label>
          <select name="scheduled" id="scheduled">
            <?php foreach ($schedule_options as $value) { 
              $selected = ($value === $scheduled->config_value) ? 'selected' : '';
              $name     = ucfirst($value);
            ?>
              <option <?php echo $selected; ?> value="<?php echo $value; ?>"><?php echo $name; ?></option>
            <?php } ?>
          </select>
        </div>
        <div class="input-group">
          <label for="time_range">Time Range</label>
          <input type="time" name="time_range[start_time]" id="start_time" value="<?php echo $start_time; ?>" />
          <input type="time" name="time_range[end_time]" id="end_time" value="<?php echo $end_time; ?>" />
        </div>
      </section>
      <section class="gk-reporting-email-message">
        <h2>Email Message</h2>
        <label class="info"><strong>[geek_logo]</strong> to display the geek logo. Use inline font styles rather than H tags.</label>
        <label class="info"><strong>[client_name]</strong> to display the client name.</label>
        <label class="info"><strong>[site_url]</strong> to display the site URL.</label>
        <label class="info"><strong>[site_name]</strong> to display the site name.</label>
        <?php 
        wp_editor($email_message, 'email_message', array(
          'media_buttons' => false,
          'textarea_name' => 'email_message',
          'textarea_rows' => 20,
          'teeny'         => false,
          'quicktags'     => true
        ));
        ?>
      </section>
      <section class="gk-reporting-recommendations">
        <h2>Recommendations</h2>
        <?php 
        wp_editor($recommendations, 'recommendations', array(
          'media_buttons' => false,
          'textarea_name' => 'recommendations',
          'textarea_rows' => 20,
          'teeny'         => false,
          'quicktags'     => true
        ));
        ?>
      </section>
      <section class="gk-reporting-save">
        <div class="input-group btn-group submit-group">
          <button type="submit" name="submit" value="save-reporting-config" class="button button-primary" >Save</button>
          <button type="submit" name="submit" value="generate-report" class="button button-primary" >Generate Report</button>
          <button type="submit" name="submit" value="clear-transient" class="button button-danger" >Clear Transient</button>
        </div>
      </section>
    </form>
  </div>
  <?php
}

function process_config_form($post) {
  $config = new gk_report_config();

  //error_log('process_config_form(): ' . print_r($post, true)); // Debugging

  if (empty($post['client_logo'])) {
    $client_logo = '';
  } else {
    $client_logo = $post['client_logo'];
  }
  if (empty($post['client_name'])) {
    $client_name = '';
  } else {
    $client_name = $post['client_name'];
  }
  if (empty($post['client_emails'])) {
    $client_emails = '';
  } else {
    $client_emails = $post['client_emails'];
  }
  if (empty($post['generated_by'])) {
    $generated_by = 'Geek Design';
  } else {
    $generated_by = $post['generated_by'];
  }
  if (empty($post['generated_email'])) {
    $generated_email = 'support@geek.design';
  } else {
    $generated_email = $post['generated_email'];
  }
  if (empty($post['author_by'])) {
    $author_by = 'Alex Clementson';
  } else {
    $author_by = $post['author_by'];
  }
  if (empty($post['subject'])) {
    $subject = 'Geek Website Report';
  } else {
    $subject = $post['subject'];
  }
  if (empty($post['scheduled'])) {
    $scheduled = 'weekly';
  } else {
    $scheduled = $post['scheduled'];
  }
  if (empty($post['time_range']) || $post['time_range']['start_time'] && $post['time_range']['end_time'] == '00:00') {
    $time_range = array(
      'start_time' => '00:00',
      'end_time'   => '06:00'
    );
  } else {
    $time_range = $post['time_range'];
  }
  /* == Trigger Time == */
  $trigger_time   = rand(strtotime($time_range['start_time']), strtotime($time_range['end_time']));

  if (empty($post['email_message'])) {
    $email_message = '';
  } else {
    $email_message = $post['email_message'];
  }
  if (empty($post['recommendations'])) {
    $recommendations = '';
  } else {
    $recommendations = $post['recommendations'];
  }

  $config->insert_update_config('client_logo', array(
    'config_value' => $client_logo,
    'updated_by'   => get_current_user_id()
  ));
  $config->insert_update_config('client_name', array(
    'config_value' => $client_name,
    'updated_by'   => get_current_user_id()
  ));
  $config->insert_update_config('client_emails', array(
    'config_value' => $client_emails,
    'updated_by'   => get_current_user_id()
  ));
  $config->insert_update_config('generated_by', array(
    'config_value' => $generated_by,
    'updated_by'   => get_current_user_id()
  ));
  $config->insert_update_config('generated_email', array(
    'config_value' => $generated_email,
    'updated_by'   => get_current_user_id()
  ));
  $config->insert_update_config('author_by', array(
    'config_value' => $author_by,
    'updated_by'   => get_current_user_id()
  ));
  $config->insert_update_config('bcc_emails', array(
    'config_value' => $post['bcc_emails'] ?? '',
    'updated_by'   => get_current_user_id()
  ));
  $config->insert_update_config('subject', array(
    'config_value' => $subject,
    'updated_by'   => get_current_user_id()
  ));
  $config->insert_update_config('scheduled', array(
    'config_value' => $scheduled,
    'updated_by'   => get_current_user_id()
  ));
  $config->insert_update_config('time_range', array(
    'config_value' => json_encode($time_range),
    'updated_by'   => get_current_user_id()
  ));
  $config->insert_update_config('trigger_time', array(
    'config_value' => $trigger_time,
    'updated_by'   => get_current_user_id()
  ));
  $config->insert_update_config('email_message', array(
    'config_value' => json_encode($email_message),
    'updated_by'   => get_current_user_id()
  ));
  $config->insert_update_config('recommendations', array(
    'config_value' => json_encode($recommendations),
    'updated_by'   => get_current_user_id()
  ));

  return true;
}

/* == Add Font Size Dropdown to TinyMCE Editor == */
function gk_customize_tinymce_buttons($buttons) {
  array_unshift($buttons, 'fontsizeselect'); // Add Font Size dropdown
  return $buttons;
}
/* == Define Available Font Sizes == */
function gk_customize_tinymce_options($initArray) {
  $initArray['fontsize_formats'] = "8px 10px 12px 14px 16px 18px 24px 36px 48px 60px 72px";
  return $initArray;
}
