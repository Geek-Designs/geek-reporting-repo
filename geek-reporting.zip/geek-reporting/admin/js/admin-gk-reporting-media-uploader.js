/* =========== Media Uploader =========== */
(function ($) {
  "use strict";

  // Initialize on document ready
  $(document).ready(function () {
    MediaUploader.init(".upload-group");
  });

  const MediaUploader = {
    init: function (groupSelector) {
      this.bindEvents(groupSelector);
    },

    bindEvents: function (groupSelector) {
      $(document).on("click", ".upload-image", function (e) {
        e.preventDefault();
        const block = $(this).closest(groupSelector);
        MediaUploader.handleImageUpload(block, false);
      });

      $(document).on("click", ".upload-image-group", function (e) {
        e.preventDefault();
        const block = $(this).closest(groupSelector);
        MediaUploader.handleImageUpload(block, true);
      });

      $(document).on("click", ".upload-video", function (e) {
        e.preventDefault();
        const block = $(this).closest(groupSelector);
        MediaUploader.handleVideoUpload(block.attr("id"));
      });
    },

    handleImageUpload: function (block, multiple) {
      const existingIds = this.getExistingIds(block);

      const mediaOptions = {
        title: multiple ? "Upload Images" : "Upload Image",
        multiple: multiple,
        library: {
          type: "image",
          size: "medium",
        },
      };

      const media = wp.media(mediaOptions);
      
      media.on("open", function () {
        const selection = media.state().get("selection");
        existingIds.forEach(function (id) {
          const attachment = wp.media.attachment(id);
          if (attachment) {
            selection.add([attachment]);
          }
        });
      });

      media.on("select", function () {
        if (!multiple) {
          MediaUploader.setSingleImage(block, media);
        } else {
          MediaUploader.setMultipleImages(block, media);
        }
      });

      media.open();
    },

    getExistingIds: function (block) {
      return block
        .find(".image-id")
        .map(function () {
          return $(this).val();
        })
        .get();
    },

    setSingleImage: function (block, media) {
      const image = media.state().get("selection").first().toJSON();

      block.find("img").attr("src", image.url);
      block.find(".image-id").val(image.id);
    },

    setMultipleImages: function (block, media) {
      const images = media
        .state()
        .get("selection")
        .map((image) => image.toJSON());
      const imageContainer = block.find(".image-group");
      let name = block.find("input").attr("name");

      if (name.includes("[")) {
        name = name.split("[")[0];
      }

      imageContainer.empty();

      images.forEach((image, index) => {
        const wrapper = $("<div>", { class: "image-wrap" });
        const img = $("<img>", { src: image.url });
        const imageIdField = $("<input>", {
          type: "hidden",
          class: "image-id",
          name: `${name}[${index + 1}]`,
          value: image.id,
        });

        wrapper.append(img, imageIdField);
        imageContainer.append(wrapper);
      });
    },
  };
})(jQuery);
