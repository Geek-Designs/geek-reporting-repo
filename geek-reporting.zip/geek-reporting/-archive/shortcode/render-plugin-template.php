<?php
/* ===== Exit if accessed directly ===== */
if(!defined('ABSPATH')) {
	exit;
}
add_shortcode('geek_plugin_template', 'render_geek_plugin_template');
function render_geek_plugin_template($atts, $content = null) {
  ob_start();
  global $wp_query;
  /*== Enqueue Styles ==*/
  if(!wp_style_is('plugin-template-css', 'enqueued')) {
    wp_enqueue_style('plugin-template-css');
  }
  /*== Enqueue Scripts ==*/
  // if(!wp_script_is('jquery'), 'enqueued') {
  //   wp_enqueue_script('jquery');
  // }
  // if(!wp_script_is('plugin-template-js', 'enqueued')) {
    // wp_enqueue_script('plugin-template-js');
  // }
  /*== Shortcode Attributes ==*/
  // $content          = wpb_js_remove_wpautop($content, true); // fix unclosed/unwanted paragraph tags in $content
  
  // error_log('Content: ' . print_r($content, true));
  error_log('Atts: ' . print_r($atts, true));

  $shortcode_atts           = array(
    'type'                  => $atts['type'] ?? '',
    'images'                => $atts['images'] ?? null,
    'columns'               => $atts['columns'] ?? '4',
    'width'                 => $atts['width'] ?? '100%',
    'height'                => $atts['height'] ?? '400px',
    'gap'                   => $atts['gap'] ?? '0',
    'id'                    => $atts['custom_id'] ?? '',
    'class'                 => $atts['custom_class'] ?? '',
  );

  error_log('Shortcode atts: ' . print_r($shortcode_atts, true));

  ?>

  <div class="<?php echo $shortcode_atts['class']; ?>" id="<?php echo $shortcode_atts['id']; ?>">
    <!-- Content here --->
  </div>

  <?php

  return ob_get_clean(); 
}