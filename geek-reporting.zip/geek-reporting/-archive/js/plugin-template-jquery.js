/* ===== jQuery ===== */
(function($) {
  /* ===== On Page Load ===== */
  $(document).ready(function() {
    //funcCallBack();
  });

  function funcCallBack() {
    // Your code here
  }
})(jQuery);