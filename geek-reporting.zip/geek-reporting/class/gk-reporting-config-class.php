<?php
if(!defined('ABSPATH')) {
	exit;
}
/* ========== Config Class ========== */
class gk_report_config {
  private $config_table;
  private $wpdb;

  public function __construct() {
    global $wpdb;
    $this->wpdb         = $wpdb;
    $this->config_table = $wpdb->prefix . 'gk_report_config';
  }
  /* == Get Config == */
  public function get_config_by_key($key) {

    if (empty($key)) {
      error_log('get_config_by_key(): No key provided');
      return false;
    }

    $sql        = $this->wpdb->prepare( 
      "SELECT * FROM $this->config_table WHERE config_key = %s",
      $key
    );
    $results    = $this->wpdb->get_row($sql);

    return !empty($results) ? $results : false;
  }
  /* == Update + Insert Config == */
  public function insert_update_config($key, $values) {

    if (empty($key)) {
      error_log('insert_update_config(): No key provided');
      return false;
    }

    $config_value = array(
      'config_value'        => $values['config_value'],
      'updated_by'          => $values['updated_by'],
      'date_updated'        => date('Y-m-d H:i:s')
    );

    $get_config = $this->get_config_by_key($key);

    if ($get_config) {
      /* == Update == */
      $insert = $this->wpdb->update($this->config_table, $config_value, array('config_key' => $key));
    } else {
      $config_value['config_key']     = $key;
      $config_value['created_by']     = $config_value['updated_by'];
      $config_value['date_created']   = $config_value['date_updated'];
      $insert = $this->wpdb->insert($this->config_table, $config_value);
    }
    if ($insert) {
      return $this->wpdb->insert_id;
    } else {
      error_log('insert_update_config(): Insert Failed');
      return false;
    }
  }
  /* == Table Create == */
  private function create_table($table_name, $table_structure) {
    $charset_collate          = $this->wpdb->get_charset_collate();
    $columns                  = array();
  
    foreach ($table_structure as $column_name => $column_definition) {
      $columns[]              = "$column_name $column_definition";
    }
  
    $sql = "CREATE TABLE $table_name (
      " . implode(",\n", $columns) . ",
      PRIMARY KEY (id)
    ) $charset_collate;";
  
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
    error_log('Table Created: ' . $table_name);
  }
  /* == Table Validate == */
  public function validate_table($table_name, $table_structure) {
    
    $current_checksum         = md5(serialize($table_structure));
    $existing_checksum        = get_option($table_name . '_checksum');
  
    /* == Check if the table exists == */
    if ($this->wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
      $this->create_table($table_name, $table_structure);
      update_option( $table_name . '_checksum', $current_checksum );
    }
    /* == Compare checksums and update table if necessary == */
    if ($current_checksum != $existing_checksum) {
      $this->create_table($table_name, $table_structure);
      update_option($table_name . '_checksum', $current_checksum);
    }
  }
}
    


