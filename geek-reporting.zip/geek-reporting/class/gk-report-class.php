<?php
if (!defined('ABSPATH')) {
  exit; 
}
/* ========== Website Report Class ========== */
class gk_report {
  private function report_variables() {
    $vars = array(
      'plugin_path'       => plugin_dir_path(dirname(__FILE__)),
      'plugin_url'        => plugin_dir_url(dirname(__FILE__)),
      'reports_path'      => plugin_dir_path(dirname(__FILE__)) . 'reports/',
      'assets_path'       => plugin_dir_path(dirname(__FILE__)) . 'assets/',
      'assets_url'        => plugin_dir_url(dirname(__FILE__)) . 'assets/',
      'page-orientation'  => 'P',
      'page-units'        => 'mm',
      'page-format'       => 'A4',
      'unicode'           => true,
      'encoding'          => 'UTF-8',
      'creator'           => 'Geek Design',
      'title'             => 'Geek Website Report',
      'subject'           => 'Geek Website Report',
      'keywords'          => 'Geek, Website, Report',
    );
    return $vars;
  }

  public function report_pdf($content) {
    $vars         = $this->report_variables();
    $tcpdf        = $vars['plugin_path'] . 'add-ons/tcpdf/tcpdf.php';

    /* == Create PDF == */
    $pdf    = new TCPDF(
      $vars['page-orientation'], 
      $vars['page-units'], 
      $vars['page-format'], 
      $vars['unicode'], 
      $vars['encoding']
    );
    /* == Set PDF Meta Data == */
    $pdf->SetCreator($vars['creator']);
    $pdf->SetTitle($vars['title'] . ' - ' . $content['overview']['site_url'] . ' - ' . $content['from_date'] . ' to ' . $content['to_date']);
    $pdf->SetSubject($vars['subject']);
    $pdf->SetKeywords($vars['keywords']);

    /* == remove default header/footer == */
    $pdf->setPrintHeader(false);
    $pdf->setPrintFooter(false);

    /* == Set Margins == */
    $pdf->SetMargins(10, 5, 10, true);

    /* == Get Font == */
    $articulat_cf_normal_path     = $vars['assets_path'] . 'fonts/articulat-cf-normal.ttf';
    $articulat_cf_bold_path       = $vars['assets_path'] . 'fonts/articulat-cf-bold.ttf';
    $articulat_cf_extra_bold_path = $vars['assets_path'] . 'fonts/articulat-cf-extra-bold.ttf';

    $articulat_cf_normal          = TCPDF_FONTS::addTTFfont($articulat_cf_normal_path);
    $articulat_cf_bold            = TCPDF_FONTS::addTTFfont($articulat_cf_bold_path);
    $articulat_cf_extra_bold      = TCPDF_FONTS::addTTFfont($articulat_cf_extra_bold_path);
    
    /* == Set Font == */
    $pdf->SetFont($articulat_cf_normal, '', 12);
    //$pdf->SetFont($articulat_cf_extra_bold, '', 12);

    /* == Get CSS == */
    $css            = file_get_contents($vars['assets_url'] . 'css/gk-report.css');
    /* == Add Cover Page == */
    $pdf->AddPage();
    $pdf->SetAutoPageBreak(false, 0);
    $background_file = $vars['assets_url'] . 'images/geek-bg.png';
    $pdf->Image($background_file, 0, 0, 210, 297, '', '', '', false, 300, '', false, false, 0);
    $pdf->SetMargins(10, 5, 15, true);
    $page_one_html  = $this->cover_page_html($content, $vars['assets_url']);
    $pdf->writeHTML($this->set_page_content($page_one_html, $css, assets_path: $vars['assets_url']), true, false, true, false, '');
    
    /* == Add Summary Page == */
    $pdf->AddPage();
    $pdf->SetMargins(10, 5, 10, true);
    $page_two_html  = $this->summary_page_html($content, $vars['assets_url']);
    $pdf->writeHTML($this->set_page_content($page_two_html, $css, $vars['assets_url']), true, false, true, false, '');

    /* == Add Update Log Page == */
    $pdf->AddPage();
    $page_three_html  = $this->update_log_page_html($content, $vars['assets_url']);
    $pdf->writeHTML($this->set_page_content($page_three_html, $css, $vars['assets_url']), true, false, true, false, '');

    /* == Add Recommendations Page == */
    $pdf->AddPage();
    $page_four_html  = $this->recommendations_page_html($content, $vars['assets_url']);
    $pdf->writeHTML($this->set_page_content($page_four_html, $css, $vars['assets_url']), true, false, true, false, '');

    /* == Add Backpage == */
    $pdf->AddPage();
    $pdf->SetAutoPageBreak(false, 0);
    $background_file = $vars['assets_url'] . 'images/geek-back-cover-bg.png';
    $pdf->Image($background_file, 0, 0, 210, 297, '', '', '', false, 300, '', false, false, 0);
    $back_page_html  = $this->back_page_html($content, $vars['assets_url']);
    $pdf->SetMargins(10, 5, 15, true);
    $pdf->writeHTML($this->set_page_content($back_page_html, $css, $vars['assets_url']), true, false, true, false, '');

    //error_log(' --> Content: ' . print_r($content, true)); // DEBUGGING ONLY

    /* == Set PDF Filename == */
    $string_replace = array('https://', 'http://', '/', '.', ':', 'www.', ' ');

    $current_date   = date('Y-m-d');
    $date_file_name = strtolower(str_replace($string_replace, '-', $current_date));
    $website_name   = str_replace( $string_replace, '', $content['overview']['site_url'] );
    $file_name      = $website_name . '-' . $date_file_name . '-report.pdf';
    $file_url       = $vars['reports_path'] . $file_name;

    $pdf->Output( $vars['reports_path'] . $file_name, 'F' );

    return $file_url;

  }
  private function set_page_content($html, $css, $assets_path) {
    $html = <<<EOF
    <style>
      @font-face {
        font-family: articulat-cf-extra-bold;
        src: url({$assets_path}fonts/Articulat-CF-Extra-Bold.ttf);
      }
      @font-face {
        font-family: articulat-cf-bold;
        src: url({$assets_path}fonts/Articulat-CF-Bold.ttf);
      }
      @font-face {
        font-family: articulat-cf-normal;
        src: url({$assets_path}fonts/Articulat-CF-Normal.ttf);
      }
      {$css}
    </style>
    {$html}
    EOF;

    return $html;
  }
  private function cover_page_html($content, $assets_path) {
    $geek_logo        = $assets_path . 'images/geek-logo.png';

    $client_logo      = $content['config']['client_logo'];
    $client_logo_src  = wp_get_attachment_image_src($client_logo, 'medium-large')[0];

    $author_by        = $content['config']['author_by'];

    $from_date        = date('F j, Y', strtotime($content['from_date']));
    $to_date          = date('F j, Y', strtotime($content['to_date']));

    $html = <<<EOF
    <div id="cover-page" class="page cover-page">
      <div class="cover-header" >
        <img src="{$geek_logo}">
      </div>
      <div class="client-logo">
        <br>
        <br>
        <br>
        <br>
        <img src="{$client_logo_src}">
      </div>
      <div class="cover-footer">
        <br class="small">
        <br class="cover">
        <h1>{$content['config']['subject']}</h1>
        <table class="details">
          <tr>
            <td colspan="3"><hr></td>
          </tr>
          <tr>
            <th><h6>Date From:</h6></th>
            <th><h6>Date To:</h6></th>
            <th><h6>Author:</h6></th>
          </tr>
          <tr>
            <td>{$from_date}</td>
            <td>{$to_date}</td>
            <td>{$author_by}</td>
          </tr>
        </table>
      </div>
    </div>
    EOF;

    return $html;
  }

  private function summary_page_html($content, $assets_path) {
    $plugin_updates = $content['update_summary']['plugins']['response'] ?? array();
    $theme_updates  = $content['update_summary']['themes']['response'] ?? array();
    $limit          = 6;

    $plugin_rows = '';
    if (!empty($plugin_updates)) {
      $counter  = 0;
      
      foreach ($plugin_updates as $plugin) {
        $counter++;
        if ($counter > $limit) {
          break;
        }
        $plugin_rows .= "<tr>
          <td>{$plugin['slug']}</td>
          <td>{$plugin['new_version']}</td>
        </tr>";
      }
    } else {
      $plugin_rows = "<tr><td colspan='2'>No plugin updates available</td></tr>";
    }

    $theme_rows = '';
    if (!empty($theme_updates)) {
      $counter  = 0;

      foreach ($theme_updates as $theme) {
        $counter++;
        if ($counter > $limit) {
          break;
        }
        $theme_rows .= "<tr>
          <td>{$theme['theme']}</td>
          <td>{$theme['new_version']}</td>
          <td>{$theme['requires']}</td>
        </tr>";
      }
    } else {
      $theme_rows = "<tr><td colspan='3'>No theme updates available</td></tr>";
    }

    $html = <<<EOF
    <div id="summary-page" class="page">
      <h2>Summary</h2>
      <table class="info-table">
        <tr>
          <td><h6>Site URL:</h6></td>
          <td colspan="3">{$content['overview']['site_url']}</td>
        </tr>
        <tr>
          <td><h6>WP Version:</h6></td>
          <td colspan="3">{$content['overview']['wp_version']}</td>
        </tr>
        <tr>
          <td><h6>PHP Version:</h6></td>
          <td colspan="3">{$content['overview']['php_version']}</td>
        </tr>
      </table>
      <h3>Plugin Updates Available:</h3>
      <table class="info-table">
        <tr>
          <th><h6>Plugin</h6></th>
          <th><h6>New Version</h6></th>
        </tr>
        {$plugin_rows}
      </table>
      <p class="small">Plugin updates limited to first {$limit}.</p>
      <h3>Theme Updates Available:</h3>
      <table class="info-table">
        <tr>
          <th><h6>Theme</h6></th>
          <th><h6>New Version</h6></th>
          <th><h6>WP Version</h6></th>
        </tr>
        {$theme_rows}
      </table>
      <p class="small">Theme updates limited to first {$limit}.</p>
    </div>
    EOF;

    return $html;
  }

  private function update_log_page_html($content, $assets_path) {
    $updates = $content['update_log'];
    $limit   = 20;
    $counter = 0;

    $update_rows = '';
    if (!empty($updates)) {
      foreach ($updates as $update) {
        $counter++;
        if ($counter > $limit) {
          break;
        }
        $update_type = ucwords(str_replace('_', ' ', $update['update_type']));
        $item_name   = ucwords(str_replace('_', ' ', $update['item_name']));

        $update_date = date('d F', strtotime($update['update_date']));
        $update_time = date('H:i', strtotime($update['update_date']));

        $update_rows .= "<tr>
          <td colspan='3'>{$update_type}</td>
          <td colspan='3'>{$item_name}</td>
          <td>{$update['old_version']}</td>
          <td>{$update['new_version']}</td>
          <td colspan='2'>{$update['status']}</td>
          <td colspan='2'>{$update_date}</td>
          <td>{$update_time}</td>
        </tr>";
      }
    } else {
      $update_rows = "<tr><td colspan='6'>No updates available</td></tr>";
    }

    $html = <<<EOF
    <div class="page update-log-page">
      <h2>Update Log</h2>
      <table class="info-table compact">
        <tr>
          <th colspan='3'><h6>Update Type</h6></th>
          <th colspan='3'><h6>Item Name</h6></th>
          <th><h6>Old Version</h6></th>
          <th><h6>New Version</h6></th>
          <th colspan='2'><h6>Status</h6></th>
          <th colspan='2'><h6>Date</h6></th>
          <th><h6>Time</h6></th>
        </tr>
        {$update_rows}
      </table>
      <p class="small">Update Log limited to first {$limit}.</p>
    </div>
    EOF;

    return $html;
  }

  private function recommendations_page_html($content, $assets_path) {
    $recommendations = $content['config']['recommendations'];

    $html = <<<EOF
    <div id="recommendations-page" class="page">
      <h2>Recommendations</h2>
      {$recommendations}
    </div>
    EOF;

    return $html;
  }
  private function back_page_html($content, $assets_path) {
    $geek_logo        = $assets_path . 'images/geek-logo.png';

    $html = <<<EOF
    <div class="page back-page">
      <div class="back-header">
        <img src="{$geek_logo}">
      </div>
      <div class="back-body">
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br><table class="h2-wrap"><tr><td colspan="3"><h2>The agency with opinions</h2></td><td colspan="2"></td></tr></table>
        <br>
        <br>
        <br>
        <h5>Web Design</h5>
        <h5>Development</h5>
        <h5>Branding</h5>
        <h5>Marketing Consultancy</h5>
        <h5>Paid Ads</h5>
        <h5>SEO</h5>
        <h5>Email Marketing</h5>
        <br>
      </div>
      <div class="back-footer">
        <table class="back-footer-table">
          <tr>
            <td class="text" colspan="9">01733 686 100</td>
            <td></td>
          </tr>
          <tr>
            <td class="text" colspan="9">www.geek.design</td>
            <td></td>
          </tr>
          <tr>
            <td class="text" colspan="9">76 Papyrus Road, Werrington, Peterborough PE4 5BH</td>
            <td></td>
          </tr>
        </table>
      </div>
    </div>
    EOF;

    return $html;
  }
}