<?php
if (!defined('ABSPATH')) {
  exit; 
}
/* ========== Website Generating Report Class ========== */
class gk_report_gen {
  private $wpdb;
  private $config_table;
  private $update_log_table;
  public function __construct() {
    global $wpdb;
    
    $this->wpdb             = $wpdb;
    $this->config_table     = $wpdb->prefix . 'gk_report_config';
    $this->update_log_table = $wpdb->prefix . 'gk_update_log';
    /* == Schedule Report == */
    add_filter('cron_schedules', array($this, 'add_custom_cron_schedule'));
    add_action('init', array($this, 'setup_cron_schedule'));
    add_action('gk_process_report', array($this, 'schedule_report')); /* Hook for the cron job */
  }
  public function setup_cron_schedule() {
    if (!wp_next_scheduled('gk_process_report')) {
      wp_schedule_event(time(), 'report_check', 'gk_process_report');
      error_log('Cron Job Scheduled');
    } else {
      do_action( 'gk_process_report' );
    }
  }

  public function add_custom_cron_schedule($schedules) {
    $schedules['report_check'] = array(
      'interval' => 600,
      'display'  => __('Every 10 Minutes'),
    );
    return $schedules;
  }

  public function check_report_schedule() {
    $config         = new gk_report_config();

    $scheduled      = $config->get_config_by_key('scheduled')->config_value;
    $trigger_time   = $config->get_config_by_key('trigger_time')->config_value;
    $next_scheduled = wp_next_scheduled('gk_process_report');
    $transient      = get_transient('gk_report_sent') ? 'true' : 'false';
    $current_time   = time();
    $time_diff      = round(($next_scheduled - $current_time) / 60); 
    $time_diff      = date('H:i', strtotime(  $time_diff ));

    $message        = '';
    $message        .= 'Scheduled at ' . date('H:i', $trigger_time);

    if ($transient === 'true') {
      $message      .= ' - Report Sent Today';
    } else {
      $message      .= ' - Report Not Sent Today';
    }

    return $message;
  }
    
  public function schedule_report() {
    error_log('Schedule Report Time: ' . date('H:i:s'));

    $log_data         = array(
      'update_date'   => date('Y-m-d H:i:s'),
      'update_type'   => 'scheduled_report',
      'item_name'     => 'Scheduled Report',
      'old_version'   => 'N/A',
      'new_version'   => 'N/A',
    );
    $log_format       = array('%s', '%s', '%s', '%s', '%s');

    $website_report   = $this->get_website_overview();
    $config           = new gk_report_config();

    $scheduled        = $config->get_config_by_key('scheduled')->config_value;
    $trigger_time     = $config->get_config_by_key('trigger_time')->config_value;
    $current_time     = time();

    $window           = 1800;
    $transient_window = 86400; // 24 hours

    $to_date          = date('Y-m-d');

    /* == Check if Report Already Sent == */
    if (get_transient('gk_report_sent')) {
      error_log('Report Already Sent');
      return;
    }

    switch ($scheduled) {
      case 'daily':
        if (abs($current_time - $trigger_time) <= $window) {
          error_log('Daily Report: ' . $to_date . ' At Time: ' . date('H:i', $current_time));
          $this->generate_report($to_date, $to_date);
          set_transient('gk_report_sent', true, $transient_window);
          $this->wpdb->insert($this->update_log_table, $log_data, $log_format);
        }
        break;

      case 'weekly':
        $current_day = date('l');
        
        if ($current_day === 'Wednesday' && abs($current_time - $trigger_time) <= $window) {
          $from_date = date('Y-m-d', strtotime('-7 days'));
          error_log('Weekly Report: ' . $from_date . ' - ' . $to_date);
          $this->generate_report($from_date, $to_date);
          set_transient('gk_report_sent', true, $transient_window);
          $this->wpdb->insert($this->update_log_table, $log_data, $log_format);
        }
        break;

      case 'monthly':
        $current_day = (int) date('j'); 
        
        if ($current_day === 1 && abs($current_time - $trigger_time) <= $window) {
          $from_date = date('Y-m-d', strtotime('-1 month'));
          error_log('Monthly Report: ' . $from_date . ' - ' . $to_date);
          $this->generate_report($from_date, $to_date);
          set_transient('gk_report_sent', true, $transient_window);
          $this->wpdb->insert($this->update_log_table, $log_data, $log_format);
        }
        break;

      case 'quarterly':
        $current_month = (int) date('n');

        if ($current_month % 3 === 0 && abs($current_time - $trigger_time) <= $window) {
          $from_date = date('Y-m-d', strtotime('-3 months'));
          error_log('Quarterly Report: ' . $from_date . ' - ' . $to_date);
          $this->generate_report($from_date, $to_date);
          set_transient('gk_report_sent', true, $transient_window);
          $this->wpdb->insert($this->update_log_table, $log_data, $log_format);
        }
        break;

      default:
        error_log('No valid schedule found.');
        break;
    }

    wp_die();
  }
  public function generate_report($from_date, $to_date) {

    $from_date  = date('Y-m-d', strtotime($from_date ?? '-7 days'));
    $to_date    = date('Y-m-d', strtotime($to_date ?? 'now'));
    $config     = $this->report_config(); 
    
    $report_data        = array(
      'overview'        => $this->get_website_overview(),
      'config'          => $config,
      'from_date'       => $from_date,
      'to_date'         => $to_date,
      'update_summary'  => $this->get_update_summary(),
      'update_log'      => $this->get_update_log($from_date, $to_date),
    );
    /* == Convert to Array == */
    $report_data        = $this->object_to_array($report_data);
    $report             = new gk_report();
    $new_report         = $report->report_pdf($report_data);

    if ($new_report) {
      //error_log('Report Generated' . print_r($new_report, true));
      /* == Send Email == */
      $this->report_email($new_report, $config);
      return $new_report;
    } else {
      error_log('Report Generation Failed');
      return false;
    }
  }

  private function report_config() {
    $config             = new gk_report_config();
    $client_logo        = $config->get_config_by_key('client_logo')->config_value;
    $client_name        = $config->get_config_by_key('client_name')->config_value;
    $client_emails      = $config->get_config_by_key('client_emails')->config_value;
    $bcc_emails         = $config->get_config_by_key('bcc_emails')->config_value;
    $generated_by       = $config->get_config_by_key('generated_by')->config_value;
    $generated_email    = $config->get_config_by_key('generated_email')->config_value;
    $author_by          = $config->get_config_by_key('author_by')->config_value;
    $subject            = $config->get_config_by_key('subject')->config_value;
    $scheduled          = $config->get_config_by_key('scheduled')->config_value;
    $recommendations    = json_decode($config->get_config_by_key('recommendations')->config_value);
    $time_range         = json_decode($config->get_config_by_key('time_range')->config_value);
    $message            = json_decode($config->get_config_by_key('email_message')->config_value);

    $return_config      = array(
      'client_logo'     => $client_logo,
      'client_name'     => $client_name,
      'client_emails'   => $client_emails,
      'bcc_emails'      => $bcc_emails,
      'generated_by'    => $generated_by,
      'generated_email' => $generated_email,
      'author_by'       => $author_by,
      'subject'         => $subject,
      'scheduled'       => $scheduled,
      'recommendations' => $recommendations,
      'time_range'      => $time_range,
      'email_message'   => $message,
    );

    return $return_config;
  }
  private function get_website_overview() {
    $data             = array(
      'site_url'      => get_site_url(),
      'ip_address'    => $_SERVER['SERVER_ADDR'],
      'wp_version'    => get_bloginfo('version'),
      'php_version'   => phpversion(),
    );

    return $data;
  }

  private function get_update_summary() {
    $updates          = get_site_transient('update_core');
    $data             = array(
      'core'          => $updates->updates[0]->response,
      'plugins'       => get_site_transient('update_plugins'),
      'themes'        => get_site_transient('update_themes')
    );

    return $data;
  }

  private function get_update_log($from_date, $to_date) {
    $sql = $this->wpdb->prepare(
      "SELECT * FROM $this->update_log_table WHERE update_date BETWEEN %s AND %s",
      $from_date,
      $to_date
    );
    $results = $this->wpdb->get_results($sql);

    /* == Filter Data for Duplicates == */
    $filtered_results     = array();
    $single_update_types  = array(
      'plugin_update_available',
      'theme_update_available',
    );

    foreach ($results as $result) {
      if (in_array($result->update_type, $single_update_types)) {
        $key      = str_replace(' ', '_', $result->item_name);
        $version  = str_replace('.', '_', $result->new_version);
        $key      = $key . '_' . $version;

        $filtered_results[$key] = $result;
      } else {
        $filtered_results[] = $result;
      }
    }

    usort($filtered_results, function ($a, $b) {
      return strtotime($a->update_date) - strtotime($b->update_date);
    });

    return $filtered_results;
  }

  private function object_to_array($data) {
    if (is_object($data)) {
      $data = (array) $data;
    }
    if (is_array($data)) {
      foreach ($data as $key => $value) {
        $data[$key] = $this->object_to_array($value);
      }
    }
    return $data;  
  }

  private function report_email($report, $config) {
    $from_email   = $config['generated_email'] ?? get_bloginfo('admin_email');
    $bcc_email    = $config['bcc_emails'];
    $from_name    = $config['generated_by'] ?? get_bloginfo('name');
    $site_url     = site_url();
    $site_name    = get_bloginfo('name');

    $to       = $config['client_emails'];
    $subject  = $config['subject'] . ' - ' . date('d-m-y') . ' - ' . $site_name;
    $logo     = $this->get_geek_logo_image();
    
    /* == Message == */
    $message  = $config['email_message'];
    $message  = str_replace('\&quot;', '', $message);
    $message  = wp_unslash($message);
    $message  = htmlspecialchars_decode($message);
    $message  = str_replace('[geek_logo]', $logo, $message);
    $message  = str_replace('[site_url]', $site_url, $message);
    $message  = str_replace('[site_name]', $site_name, $message);
    $message  = str_replace('[client_name]', $config['client_name'], $message);
    $message  = nl2br(trim($message));

    $headers  = array(
      'Content-Type: text/html; charset=UTF-8',
      'From: ' . $from_name . ' <' . $from_email . '>',
      'Bcc: ' . $bcc_email, 
    );
    $attachments = array($report);

    wp_mail($to, $subject, $message, $headers, $attachments);

    return true;
  }
  private function get_geek_logo_image() {
    $html = '<a href="https://geek.design"><img src="https://geek.design/wp-content/uploads/2025/02/Logo-GD.jpg" alt="Geek Design" style="width: 100px; height: auto;"></a>';
    return $html;
  }
}