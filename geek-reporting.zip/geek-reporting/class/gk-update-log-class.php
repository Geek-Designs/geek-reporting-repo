<?php
if (!defined('ABSPATH')) {
  exit;
}
/* ========== Update Log Class ========== */
class gk_update_log {
  private $update_log_table;
  private $wpdb;

  public function __construct() {
    global $wpdb;
    $this->wpdb             = $wpdb;
    $this->update_log_table = $wpdb->prefix . 'gk_update_log';
    $this->register_hooks();
  }
  private function register_hooks(){
    /* == Register Hooks == */
    add_action('upgrader_process_complete', array($this, 'handle_installation'), 10, 2);
    /* == Plugin Activation/Deactivation == */
    add_action('activated_plugin', [$this, 'handle_plugin_activation']);
    add_action('deactivated_plugin', [$this, 'handle_plugin_deactivation']);
    add_action('delete_plugin', [$this, 'handle_plugin_delete']);
    add_action('deleted_plugin', [$this, 'handle_plugin_delete']);
    /* == Failed Updates == */
    add_action('upgrader_process_complete', [$this, 'handle_failed_updates'], 10, 2);
    add_action('automatic_updates_complete', [$this, 'handle_failed_automatic_updates'], 10, 1);
    /* == Theme Activation/Deactivation == */
    add_action('switch_theme', [$this, 'handle_theme_switch'], 10, 3);
    add_action('after_switch_theme', [$this, 'handle_theme_activation']);
    add_action('delete_theme', [$this, 'handle_theme_delete']);
    add_action('deleted_theme', [$this, 'handle_theme_delete']);
    /* == Database Updates == */
    add_action('automatic_updates_complete', [$this, 'handle_automatic_updates'], 10, 1);
    add_action('update_feedback', [$this, 'handle_update_feedback'], 10, 1);
    /* == File Modifications == */
    //add_action('file_mod_allowed', [$this, 'track_file_modifications'], 10, 2); // Disabled for now
    add_action( 'file_mod_not_allowed', [$this, 'track_file_modifications'], 10, 2 );
    /* == Auto-updates == */
    add_action('update_option_auto_update_core_major', [$this, 'log_auto_update_preference'], 10, 2);
    add_action('update_option_auto_update_plugins', [$this, 'log_auto_update_preference'], 10, 2);
    add_action('update_option_auto_update_themes', [$this, 'log_auto_update_preference'], 10, 2);
    /* == Update Availability == */
    add_action('set_site_transient_update_plugins', [$this, 'check_plugin_updates']);
    add_action('set_site_transient_update_themes', [$this, 'check_theme_updates']);
  }
  /* == Handle Public Activation/Updates == */
  public function handle_update_log($upgrader, $options) {
    $this->log_update($upgrader, $options);
  }
  public function handle_failed_updates($upgrader, $options) {
    if (!empty($upgrader->skin->result_errors)) {
      $errors = $upgrader->skin->result_errors;
      $type = isset($options['type']) ? $options['type'] : 'unknown';

      $data = array(
        'update_type' => $type . '_update_failed',
        'item_name'   => $this->get_item_name($upgrader, $options),
        'old_version' => $this->get_current_version($type),
        'new_version' => '',
        'status'      => 'failed',
        'update_data' => json_encode([
          'errors'        => $errors->get_error_messages(),
          'error_codes'   => $errors->get_error_codes(),
          'update_info'   => $options
        ])
      );

      $this->wpdb->insert($this->update_log_table, $data, ['%s', '%s', '%s', '%s', '%s', '%s']);
    }
  }
  public function handle_failed_automatic_updates($results) {
    if (!empty($results['failed'])) {
      foreach ($results['failed'] as $type => $failure) {
        $data = [
          'update_type' => $type . '_auto_update_failed',
          'item_name'   => $failure->item->name ?? 'Unknown',
          'old_version' => $failure->item->current_version ?? '',
          'new_version' => $failure->item->new_version ?? '',
          'status'      => 'failed',
          'update_data' => json_encode([
            'error' => $failure->error->get_error_message(),
            'code'  => $failure->error->get_error_code()
          ])
        ];
        $this->wpdb->insert($this->update_log_table, $data, ['%s', '%s', '%s', '%s', '%s', '%s']);
      }
    }
  }
  public function handle_plugin_installed($plugin) {
    if (empty($plugin)) {
      return;
    }

    $plugin_data    = get_plugin_data(WP_PLUGIN_DIR . '/' . $plugin);
    $data           = array(
      'update_type' => 'plugin_install',
      'item_name'   => $plugin_data['Name'],
      'old_version' => '',
      'new_version' => $plugin_data['Version'],
      'status'      => 'installed'
    );

    $this->wpdb->insert($this->update_log_table, $data, ['%s', '%s', '%s', '%s', '%s']);
  }
  public function handle_plugin_activation($plugin) {
    if (empty($plugin)) {
      return;
    }

    $plugin_data    = get_plugin_data(WP_PLUGIN_DIR . '/' . $plugin);
    $data           = array(
      'update_type' => 'plugin_activation',
      'item_name'   => $plugin_data['Name'],
      'old_version' => '',
      'new_version' => $plugin_data['Version'],
      'status'      => 'activated'
    );

    $this->wpdb->insert($this->update_log_table, $data, ['%s', '%s', '%s', '%s', '%s']);
  }
  public function handle_plugin_deactivation($plugin) {
    if (empty($plugin)) {
      return;
    }

    $plugin_data    = get_plugin_data(WP_PLUGIN_DIR . '/' . $plugin);
    $data           = array(
      'update_type' => 'plugin_deactivation',
      'item_name'   => $plugin_data['Name'],
      'old_version' => $plugin_data['Version'],
      'new_version' => '',
      'status'      => 'deactivated'
    );

    $this->wpdb->insert($this->update_log_table, $data, ['%s', '%s', '%s', '%s', '%s']);
  }
  public function handle_plugin_delete($plugin) {
    if (empty($plugin)) {
      error_log('Plugin deletion handler: Empty plugin path provided');
      return;
    }

    // Full path to plugin file
    $plugin_path = WP_PLUGIN_DIR . '/' . $plugin;

    // Verify plugin file exists
    if (!file_exists($plugin_path)) {
      error_log('Plugin deletion handler: Plugin file not found - ' . $plugin_path);
      return;
    }

    // Get plugin data before deletion
    $plugin_data = get_plugin_data($plugin_path, false, false);

    if (empty($plugin_data['Name'])) {
      error_log('Plugin deletion handler: Unable to get plugin data - ' . $plugin);
      return;
    }

    $data = array(
      'update_type' => 'plugin_delete',
      'item_name'   => $plugin_data['Name'],
      'old_version' => $plugin_data['Version'],
      'new_version' => '',
      'status'      => 'deleted',
      'update_data' => json_encode([
        'plugin_file' => $plugin,
        'plugin_data' => [
          'Author'      => $plugin_data['Author'],
          'AuthorURI'   => $plugin_data['AuthorURI'],
          'TextDomain'  => $plugin_data['TextDomain'],
          'DomainPath' => $plugin_data['DomainPath']
        ]
      ])
    );

    $this->wpdb->insert(
      $this->update_log_table,
      $data,
      ['%s', '%s', '%s', '%s', '%s', '%s']
    );
  }
  public function handle_theme_switch($new_name, $new_theme, $old_theme) {
    if (empty($new_name)) {
      return;
    }

    $data           = array(
      'update_type' => 'theme_switch',
      'item_name'   => $new_name,
      'old_version' => $old_theme->get('Version'),
      'new_version' => $new_theme->get('Version'),
      'status'      => 'switched'
    );

    $this->wpdb->insert($this->update_log_table, $data, ['%s', '%s', '%s', '%s', '%s']);
  }
  public function handle_theme_activation() {
    $new_theme = wp_get_theme();

    // Skip if theme data isn't valid
    if (!$new_theme->exists()) {
      error_log('Theme activation handler: Invalid theme');
      return;
    }

    $data = array(
      'update_type' => 'theme_activation',
      'item_name'   => $new_theme->get('Name'),
      'old_version' => '',
      'new_version' => $new_theme->get('Version'),
      'status'      => 'activated',
      'update_data' => json_encode([
        'stylesheet'    => $new_theme->get_stylesheet(),
        'template'     => $new_theme->get_template(),
        'theme_data'   => [
          'Author'     => $new_theme->get('Author'),
          'AuthorURI'  => $new_theme->get('AuthorURI'),
          'Template'   => $new_theme->get('Template')
        ]
      ])
    );

    $this->wpdb->insert(
      $this->update_log_table,
      $data,
      ['%s', '%s', '%s', '%s', '%s', '%s']
    );
  }
  public function handle_theme_delete($theme) {
    if (empty($theme)) {
      error_log('Theme deletion handler: Empty theme path provided');
      return;
    }

    // Full path to theme directory
    $theme_path = get_theme_root() . '/' . $theme;

    // Verify theme directory exists
    if (!is_dir($theme_path)) {
      error_log('Theme deletion handler: Theme directory not found - ' . $theme_path);
      return;
    }

    // Get theme data before deletion
    $theme_data = wp_get_theme($theme);

    if (empty($theme_data->get('Name'))) {
      error_log('Theme deletion handler: Unable to get theme data - ' . $theme);
      return;
    }

    $data = array(
      'update_type' => 'theme_delete',
      'item_name'   => $theme_data->get('Name'),
      'old_version' => $theme_data->get('Version'),
      'new_version' => '',
      'status'      => 'deleted',
      'update_data' => json_encode([
        'theme_path' => $theme_path,
        'theme_data' => [
          'Author'     => $theme_data->get('Author'),
          'AuthorURI'  => $theme_data->get('AuthorURI'),
          'Template'   => $theme_data->get('Template')
        ]
      ])
    );

    $this->wpdb->insert(
      $this->update_log_table,
      $data,
      ['%s', '%s', '%s', '%s', '%s', '%s']
    );
  }
  public function handle_automatic_updates($results) {
    if (!empty($results['db'])) {
      $data = array(
        'update_type' => 'database_update',
        'item_name'   => 'WordPress Database',
        'old_version' => get_option('db_version'),
        'new_version' => $GLOBALS['wp_db_version'],
        'status'      => 'completed',
        'update_data' => json_encode([
          'results'      => $results['db'],
          'db_charset'   => DB_CHARSET,
          'db_collate'   => DB_COLLATE
        ])
      );

      $this->wpdb->insert($this->update_log_table, $data, ['%s', '%s', '%s', '%s', '%s', '%s']);
    }
  }

  public function handle_update_feedback($results) {
    if (!empty($results['feedback'])) {
      $data = array(
        'update_type' => 'update_feedback',
        'item_name'   => 'WordPress Core',
        'old_version' => get_bloginfo('version'),
        'new_version' => $results['feedback']['version'],
        'status'      => 'completed',
        'update_data' => json_encode([
          'results'      => $results['feedback'],
          'php_version'  => PHP_VERSION,
          'mysql_version' => $this->wpdb->db_version(),
          'is_multisite' => is_multisite(),
          'locale'       => get_locale()
        ])
      );

      $this->wpdb->insert($this->update_log_table, $data, ['%s', '%s', '%s', '%s', '%s', '%s']);
    }
  }
  public function track_file_modifications($allowed, $context) {
    
    $data = array(
      'update_type' => 'file_modification_blocked',
      'item_name'   => $context,
      'old_version' => '',
      'new_version' => '',
      'status'      => 'blocked',
      'update_data' => json_encode([
        'context'       => $context,
        'constants'     => [
          'DISALLOW_FILE_MODS' => defined('DISALLOW_FILE_MODS') ? DISALLOW_FILE_MODS : true,
          'DISALLOW_FILE_EDIT' => defined('DISALLOW_FILE_EDIT') ? DISALLOW_FILE_EDIT : true
        ],
        'user_id'       => get_current_user_id(),
        'request_time'  => current_time('mysql')
      ])
    );

    $this->wpdb->insert($this->update_log_table, $data, ['%s', '%s', '%s', '%s', '%s', '%s']);
  }
  public function log_auto_update_preference($old_value, $new_value) {
    $type = str_replace('auto_update_', '', current_filter());

    $data = array(
      'update_type' => 'auto_update_preference',
      'item_name'   => $type,
      'old_version' => json_encode($old_value),
      'new_version' => json_encode($new_value),
      'status'      => 'changed',
      'update_data' => json_encode([
        'user_id'       => get_current_user_id(),
        'change_time'   => current_time('mysql'),
        'type'          => $type
      ])
    );

    $this->wpdb->insert($this->update_log_table, $data, ['%s', '%s', '%s', '%s', '%s', '%s']);
  }
  public function check_plugin_updates($transient) {
    if (empty($transient->response)) {
      return;
    }

    foreach ($transient->response as $plugin_file => $plugin_data) {
      $plugin = get_plugin_data(WP_PLUGIN_DIR . '/' . $plugin_file);

      $data = array(
        'update_type' => 'plugin_update_available',
        'item_name'   => $plugin['Name'],
        'old_version' => $plugin['Version'],
        'new_version' => $plugin_data->new_version,
        'status'      => 'pending',
        'update_data' => json_encode([
          'slug'          => $plugin_data->slug,
          'url'           => $plugin_data->url,
          'package'       => $plugin_data->package,
          'requires'      => $plugin_data->requires,
          'requires_php'  => $plugin_data->requires_php
        ])
      );

      $this->wpdb->insert($this->update_log_table, $data, ['%s', '%s', '%s', '%s', '%s', '%s']);
    }
  }
  public function check_theme_updates($transient) {
    if (empty($transient->response)) {
      return;
    }

    foreach ($transient->response as $stylesheet => $theme_data) {
      $theme = wp_get_theme($stylesheet);

      $data = array(
        'update_type' => 'theme_update_available',
        'item_name'   => $theme->get('Name'),
        'old_version' => $theme->get('Version'),
        'new_version' => $theme_data['new_version'],
        'status'      => 'pending',
        'update_data' => json_encode([
          'package'       => $theme_data['package'],
          'requires'      => $theme_data['requires'],
          'requires_php'  => $theme_data['requires_php']
        ])
      );

      $this->wpdb->insert($this->update_log_table, $data, ['%s', '%s', '%s', '%s', '%s', '%s']);
    }
  }
  private function log_update($upgrader, $options) {
    if (!isset($options['type'])) {
      return;
    }

    // Skip if this is an installation
    if (isset($options['action']) && $options['action'] === 'install') {
      return;
    }

    $update_type  = $options['type'];
    $item_name    = '';
    $old_version  = '';
    $new_version  = '';
    $status       = 'completed';
    $update_data  = [];

    switch ($update_type) {
      case 'core':
        $this->handle_core_update($upgrader, $options);
        break;

      case 'plugin':
        $this->handle_plugin_update($upgrader, $options);
        break;

      case 'theme':
        $this->handle_theme_update($upgrader, $options);
        break;
    }
  }
  private function handle_core_update($upgrader, $options) {
    $core_update = get_option('_site_transient_update_core');

    if (!$core_update || !isset($upgrader->core_upgrader->result['version'])) {
      return;
    }

    $data = array(
      'update_type' => 'core',
      'item_name'   => 'WordPress Core',
      'old_version' => $core_update->updates[0]->current,
      'new_version' => $upgrader->core_upgrader->result['version'],
      'status'      => 'completed',
      'update_data' => json_encode([
        'php_version'    => PHP_VERSION,
        'mysql_version'  => $this->wpdb->db_version(),
        'is_multisite'   => is_multisite(),
        'locale'         => get_locale()
      ])
    );

    $this->wpdb->insert($this->update_log_table, $data, ['%s', '%s', '%s', '%s', '%s', '%s']);
  }
  private function handle_plugin_update($upgrader, $options) {
    if (!isset($options['plugins']) || empty($options['plugins'])) {
      return;
    }

    foreach ($options['plugins'] as $plugin) {
      $plugin_data = get_plugin_data(WP_PLUGIN_DIR . '/' . $plugin);

      // Get the previous version from our logs
      $old_version = $this->wpdb->get_var($this->wpdb->prepare(
        "SELECT new_version 
            FROM {$this->update_log_table} 
            WHERE item_name = %s 
            AND update_type IN ('plugin_activation', 'plugin_update')
            ORDER BY update_date DESC 
            LIMIT 1",
        $plugin_data['Name']
      ));

      $data = array(
        'update_type' => 'plugin_update',
        'item_name'   => $plugin_data['Name'],
        'old_version' => $old_version,
        'new_version' => $plugin_data['Version'],
        'status'      => 'completed',
        'update_data' => json_encode([
          'plugin_file'   => $plugin,
          'requires_wp'   => $plugin_data['RequiresWP'],
          'requires_php'  => $plugin_data['RequiresPHP'],
          'network'       => is_plugin_active_for_network($plugin)
        ])
      );

      $this->wpdb->insert($this->update_log_table, $data, ['%s', '%s', '%s', '%s', '%s', '%s']);
    }
  }
  private function handle_theme_update($upgrader, $options) {
    if (!isset($options['themes']) || empty($options['themes'])) {
      return;
    }

    foreach ($options['themes'] as $theme) {
      $theme_data = wp_get_theme($theme);

      // Get the previous version from our logs
      $old_version = $this->wpdb->get_var($this->wpdb->prepare(
        "SELECT new_version 
            FROM {$this->update_log_table} 
            WHERE item_name = %s 
            AND update_type IN ('theme_activation', 'theme_update')
            ORDER BY update_date DESC 
            LIMIT 1",
        $theme_data->get('Name')
      ));

      $data = array(
        'update_type' => 'theme_update',
        'item_name'   => $theme_data->get('Name'),
        'old_version' => $old_version,
        'new_version' => $theme_data->get('Version'),
        'status'      => 'completed',
        'update_data' => json_encode([
          'stylesheet'    => $theme_data->get_stylesheet(),
          'template'     => $theme_data->get_template(),
          'requires_wp'  => $theme_data->get('RequiresWP'),
          'requires_php' => $theme_data->get('RequiresPHP')
        ])
      );

      $this->wpdb->insert($this->update_log_table, $data, ['%s', '%s', '%s', '%s', '%s', '%s']);
    }
  }
  public function handle_installation($upgrader, $options) {
    if (!isset($options['type']) || !isset($options['action']) || $options['action'] !== 'install') {
      return;
    }

    switch ($options['type']) {
      case 'plugin':
        if (isset($options['plugins'])) {
          foreach ($options['plugins'] as $plugin) {
            $this->log_plugin_installation($plugin);
          }
        }
        break;

      case 'theme':
        if (isset($options['themes'])) {
          foreach ($options['themes'] as $theme) {
            $this->wpdb->insert($this->update_log_table, [
              'update_type' => 'theme_install',
              'item_name'   => $theme,
              'old_version' => '',
              'new_version' => wp_get_theme($theme)->get('Version'),
              'status'      => 'installed'
            ], ['%s', '%s', '%s', '%s', '%s']);
          }
        }
        break;
    }
  }
  private function get_current_version($type) {
    switch ($type) {
      case 'core':
        return get_bloginfo('version');
      case 'plugin':
        return '';
      case 'theme':
        return '';
      default:
        return '';
    }
  }
  private function get_item_name($upgrader, $options) {
    switch ($options['type']) {
      case 'core':
        return 'WordPress Core';
      case 'plugin':
        $plugin_data = get_plugin_data($upgrader->skin->plugin_file);
        return $plugin_data['Name'];
      case 'theme':
        return $upgrader->skin->theme_name;
      default:
        return 'Unknown';
    }
  }
}
