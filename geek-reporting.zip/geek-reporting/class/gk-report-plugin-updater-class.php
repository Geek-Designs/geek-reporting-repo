<?php
if (!defined('ABSPATH')) {
  exit;
}

/* ========== Plugin Auto Updater ========== */
class gk_report_plugin_updater {
  private $plugin_slug;
  private $plugin_version;
  private $github_user;
  private $github_repo;
  private $github_api_url;
  private $plugin_file;

  public function __construct($plugin_file, $plugin_slug, $plugin_version, $github_user, $github_repo) {
    $this->plugin_file    = $plugin_file;
    $this->plugin_slug    = $plugin_slug;
    $this->plugin_version = $plugin_version;
    $this->github_user    = $github_user;
    $this->github_repo    = $github_repo;
    $this->github_api_url = sprintf('https://api.github.com/repos/%s/%s/releases/latest', $this->github_user, $this->github_repo);

    /* ====== Add Filters ====== */
    add_filter('pre_set_site_transient_update_plugins', array($this, 'check_for_update'));
    add_filter('plugins_api', array($this, 'plugin_popup'), 10, 3);
    add_filter('upgrader_post_install', array($this, 'after_install'), 10, 3);
  }

  /* ====== Check for Plugin Update ====== */
  public function check_for_update($transient) {
    if (empty($transient->checked)) {
      return $transient;
    }

    $plugin_data = get_plugin_data($this->plugin_file);
    $current_version = $plugin_data['Version'];

    $remote_version = $this->get_remote_version();
    if (!$remote_version || version_compare($current_version, $remote_version, '>=')) {
      return $transient;
    }

    $obj = new stdClass();
    $obj->slug = $this->plugin_slug;
    $obj->new_version = $remote_version;
    $obj->url = "https://github.com/{$this->github_user}/{$this->github_repo}/releases";
    $obj->package = $this->get_download_url($remote_version);

    $transient->response[$this->plugin_file] = $obj;
    return $transient;
  }

  /* ====== Get Latest Release Version from GitHub ====== */
  public function get_remote_version() {
    $request = wp_remote_get($this->github_api_url, array('timeout' => 10));

    if (is_wp_error($request) || wp_remote_retrieve_response_code($request) !== 200) {
      return false;
    }

    $body = wp_remote_retrieve_body($request);
    $json = json_decode($body, true);

    if (!$json || !isset($json['tag_name'])) {
      return false;
    }

    return ltrim($json['tag_name'], 'v'); /* Remove 'v' prefix if present */
  }

  /* ====== Get Download URL for the Latest Release ====== */
  public function get_download_url($version) {
    $request = wp_remote_get($this->github_api_url, array('timeout' => 10));

    if (is_wp_error($request) || wp_remote_retrieve_response_code($request) !== 200) {
      return false;
    }

    $body = wp_remote_retrieve_body($request);
    $json = json_decode($body, true);

    if (!$json || !isset($json['assets'][0]['browser_download_url'])) {
      return false;
    }

    return $json['assets'][0]['browser_download_url'];
  }

  /* ====== Display Update Information in WP Admin Popup ====== */
  public function plugin_popup($false, $action, $args) {
    if ($action !== 'plugin_information' || $args->slug !== $this->plugin_slug) {
      return false;
    }

    $request = wp_remote_get($this->github_api_url, array('timeout' => 10));

    if (is_wp_error($request) || wp_remote_retrieve_response_code($request) !== 200) {
      return false;
    }

    $body = wp_remote_retrieve_body($request);
    $json = json_decode($body, true);

    if (!$json || !isset($json['tag_name'])) {
      return false;
    }

    return (object) array(
      'name'          => $this->plugin_slug,
      'slug'          => $this->plugin_slug,
      'version'       => ltrim($json['tag_name'], 'v'),
      'author'        => '<a href="https://yourwebsite.com">Your Name</a>',
      'homepage'      => $json['html_url'],
      'download_link' => $this->get_download_url($json['tag_name']),
      'sections'      => array(
        'description' => $json['body'] ?? 'No description available.',
      ),
    );
  }

  /* ====== Handle Post-Update Actions ====== */
  public function after_install($response, $hook_extra, $result) {
    if ($hook_extra['plugin'] !== $this->plugin_file) {
      return $response;
    }

    /* Additional actions after updating */
    error_log('Plugin Updated Successfully');
    return $response;
  }
}
