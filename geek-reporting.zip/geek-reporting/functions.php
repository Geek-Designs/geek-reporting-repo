<?php
if(!defined('ABSPATH')) {
	exit;
}
/*
* Plugin Name: Geek Reporting
* Description: A simple reporting plugin for Geek Design Websites.
* Version: 1.0
* Author: Geek Design, Alex Clementson-Walker, Chris Nurney
* Author URI: https://geek.design
* License: GPL2
*/
/* ===== Includes ===== */
/* = Class = */
require( plugin_dir_path( __FILE__ ) . 'class/gk-report-class.php' );
require( plugin_dir_path( __FILE__ ) . 'class/gk-reporting-config-class.php' );
require( plugin_dir_path( __FILE__ ) . 'class/gk-report-gen-class.php' );
require( plugin_dir_path( __FILE__ ) . 'class/gk-update-log-class.php' );
require( plugin_dir_path( __FILE__ ) . 'class/gk-report-plugin-updater-class.php' );
/* = Admin = */
require( plugin_dir_path( __FILE__ ) . 'admin/admin-functions.php' );
require( plugin_dir_path( __FILE__ ) . 'admin/option-pages/gk-reporting-options-page.php' );
/* = Shortcodes = */
/* = AJAX = */
/* = Addons = */
require( plugin_dir_path( __FILE__ ) . 'add-ons/tcpdf/tcpdf.php' );
/* = Actions = */
//add_action( 'wp_enqueue_scripts', 'gk_reporting_register_styles', 120 );
//add_action( 'wp_enqueue_scripts', 'gk_reporting_register_scripts', 120 );
add_action( 'admin_enqueue_scripts', 'admin_gk_reporting_register_scripts', 120 );
add_action( 'admin_menu', 'gk_remove_menu_items', 999 );
/* = Filters = */
/* = Activation / Deactivation = */
register_activation_hook( __FILE__, 'gk_reporting_activation' );
//register_deactivation_hook( __FILE__, 'gk_reporting_deactivation' );

/* = Global Variables = */
$update_logger = new gk_update_log();
$report_gen    = new gk_report_gen();
$updater       = new gk_report_plugin_updater(
  __FILE__,                      
  'geek-reporting',          
  '1.0.0',                        
  'your-github-username',       
  'your-plugin-repository-name' 
);
/* ===== Functions ===== */
function gk_reporting_register_styles() {
  $plugin_url   = plugin_dir_url( __FILE__ );
  wp_register_style( 'gk-reporting-css', $plugin_url . 'css/gk-reporting.css', array(), date('h:i:s'), 'all' );
}
function gk_reporting_register_scripts() {
  $plugin_url   = plugin_dir_url( __FILE__ );
  // if(!wp_script_is('jquery'), 'enqueued') {
  //   wp_enqueue_script('jquery');
  // }
  //wp_register_script( 'gk-reporting-js', $plugin_url . 'js/gk-reporting.js', array(), date('h:i:s'), true );
  // wp_localize_script('geek_gk_reporting_ajax', 'wp_ajax', array( 'ajax_url' => admin_url('admin-ajax.php') ) );
}
function admin_gk_reporting_register_scripts() {
  $plugin_url   = plugin_dir_url( __FILE__ );
  wp_register_style( 'admin-gk-reporting-css', $plugin_url . 'admin/css/admin-gk-reporting.css', array(), date('h:i:s'), 'all' );
  wp_register_script( 'admin-gk-reporting-media-uploader', $plugin_url . 'admin/js/admin-gk-reporting-media-uploader.js', array('jquery'), date('h:i:s'), true );
  //wp_register_script( 'admin-gk-reporting-jquery', $plugin_url . 'admin/js/admin-gk-reporting-jquery.js', array('jquery'), date('h:i:s'), true );
}
function gk_reporting_activation() {
  gk_clear_error_log('Geek Reporting Plugin Activated');
  create_gk_reports();
  create_gk_update_log();
  create_gk_report_config();
}
function gk_reporting_deactivation() {
  // Deactivation code here...
}
/* ========== Validate Database Tables ========== */
function create_gk_reports() {
  global $wpdb;
  $gk_report_config               = new gk_report_config();

  $table_name                     = $wpdb->prefix . 'gk_reports';
  $table_structure                = array(
    'id'                          => 'BIGINT(20) NOT NULL AUTO_INCREMENT',
    'status'                      => 'VARCHAR(255) DEFAULT "draft"',
    'date_created'                => 'DATETIME DEFAULT CURRENT_TIMESTAMP',
    'created_by'                  => 'BIGINT(20) NOT NULL',
    'content'                     => 'LONGTEXT',
  );
  $gk_report_config->validate_table($table_name, $table_structure);
}
function create_gk_update_log() {
  global $wpdb;
  $gk_report_config               = new gk_report_config();

  $table_name                     = $wpdb->prefix . 'gk_update_log';
  $table_structure                = array(
    'id'                          => 'BIGINT(20) NOT NULL AUTO_INCREMENT',
    'update_type'                 => 'VARCHAR(255) NOT NULL',
    'item_name'                   => 'VARCHAR(255) NOT NULL',
    'old_version'                 => 'VARCHAR(255) NOT NULL',
    'new_version'                 => 'VARCHAR(255) NOT NULL',
    'status'                      => 'VARCHAR(255) NOT NULL',
    'update_date'                 => 'DATETIME DEFAULT CURRENT_TIMESTAMP',
    'update_data'                 => 'LONGTEXT',
  );
  $gk_report_config->validate_table($table_name, $table_structure);
}
function create_gk_report_config() {
  global $wpdb;
  $gk_report_config               = new gk_report_config();

  $table_name                     = $wpdb->prefix . 'gk_report_config';
  $table_structure                = array(
    'id'                          => 'BIGINT(20) NOT NULL AUTO_INCREMENT',
    'config_key'                  => 'VARCHAR(255) NOT NULL',
    'config_value'                => 'LONGTEXT',
    'created_by'                  => 'BIGINT(20) NOT NULL',
    'date_created'                => 'DATETIME DEFAULT CURRENT_TIMESTAMP',
    'updated_by'                  => 'BIGINT(20) NOT NULL',
    'date_updated'                => 'DATETIME DEFAULT CURRENT_TIMESTAMP',
  );
  $gk_report_config->validate_table($table_name, $table_structure);
}
/* ========== Delete Error/Debug Log ========== */
function gk_clear_error_log($note = '') {
  file_put_contents(WP_CONTENT_DIR . '/debug.log', '');
  error_log('<------------------------ GK Debug Log Cleared ' . $note . ' ------------------------->');
}

function gk_remove_menu_items() {
  $current_user     = wp_get_current_user();
  $user_email       = $current_user->user_email;
  $geek_email       = '@geek.design';
  
  if (strpos($user_email, $geek_email) !== false) {
    /* ===== Operate as Normal ===== */
  } else {
    remove_menu_page( 'gk-reporting' );
  }
}
