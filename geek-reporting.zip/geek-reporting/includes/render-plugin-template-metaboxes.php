<?php
if(!defined('ABSPATH')) {
	exit;
}
/* ====== Actions ====== */
add_action( 'add_meta_boxes', 'render_metaboxes' );
add_action( 'save_post', 'update_post_metaboxes', 10, 2 );
/* ====== Functions ====== */
function render_metaboxes() {
  $domain                  = 'custom_metabox_domain';
  //wp_enqueue_style( 'admin-style' ); // Enqueue admin styles
  add_meta_box( 
    'custom_metabox', // id
    __('Custom Metabox', $domain), // Title
    'render_metabox', // callback metabox function
    'post', // post type
    'normal', // context
    'high' // priority
  );
}
/* ====== Metaboxes ====== */
function render_metabox( $post ) {
  $domain                  = 'custom_metabox_domain';
  //$metabox_array_fields     = get_post_meta( $post->ID ,'metabox_array', true ) ?: array();
  //delete_post_meta( $post->ID ,'e_course_details' ); // Remove old meta
  $metabox_field           = get_post_meta( $post->ID ,'metabox_field', true) ?? '';
  $metabox_img             = get_post_meta( $post->ID ,'metabox_img', true) ?? '';

  /* == Admin jQuery Scripts == */
  // if(!wp_script_is('jquery', 'enqueued')) {
  //   wp_enqueue_script('jquery');
  // }
  // if(!wp_script_is('admin-plugin-template-jquery', 'enqueued')) {
  //   wp_enqueue_script( 'admin-plugin-template-jquery' );
  // }
  /* == Admin Styles == */
  if(!wp_style_is('admin-plugin-template-css', 'enqueued')) {
    wp_enqueue_style( 'admin-plugin-template-css' );
  }

  ?>
  <div class="meta-group">
    <label for="metabox_field"><?php _e( 'Metabox Field', $domain ); ?></label>
    <input type="text" name="metabox_field" id="metabox-field" value="<?php echo $metabox_field; ?>" />
  </div>

  <div class="meta-group">
    <label for="metabox_img"><?php _e( 'Metabox Image', $domain ); ?></label>
    <input type="text" name="metabox_img" id="metabox-img-url" class="hidden" value="<?php echo $metabox_img; ?>" />
    <button class="button" id="metabox-img-upload">Upload</button>
    <img id="metabox-img" src="<?php echo $metabox_img; ?>" alt="Metabox Image" style="width: 100px; height: auto; display: block; margin-top: 10px;" />
  </div>

  <script type="text/javascript">
    jQuery(document).ready(function($) {

      $('#metabox-img-upload').click( upload_media_image('#metabox-img-upload', '#metabox-img') );
      // $('#metabox-img-upload').click(function(e) {
      //   e.preventDefault();
      //   var image = wp.media({
      //     title: 'Upload Image',
      //     multiple: false
      //   }).open()
      //   .on('select', function(e) {
      //     var uploaded_image = image.state().get('selection').first();
      //     var image_url = uploaded_image.toJSON().url;
      //     $('#metabox-img-url').val(image_url);
      //     $('#metabox-img').attr('src', image_url);
      //   });
      // });

    });
  </script>

  <?php
}
/* ====== Save Metaboxes ====== */
function update_post_metaboxes( $post_id, $post ) {
  $domain           = 'custom_metabox_domain';

  if ($_POST['metabox_field'] != null && $_POST['metabox_field'] != '') {
    $metabox_field    = $_POST['metabox_field'];
    update_post_meta( $post_id, 'metabox_field', $metabox_field );
  }
}