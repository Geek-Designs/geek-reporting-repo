<?php
if(!defined('ABSPATH')) {
	exit;
}
/* ===== Init Actions ===== */
add_action('init', 'register_plugin_template_post_type');
/* ===== Post Type ===== */
function register_plugin_template_post_type() {
	$post_type_singular  = 'Plugin Template';
	$post_type_plural    = 'Plugin Templates';
	$post_type_slug      = 'plugin-template';

	register_post_type( $post_type_slug ,
		array(
			'labels'      => array(
				'name'               => __( $post_type_plural, 'textdomain' ),
				'singular_name'      => __( $post_type_singular, 'textdomain' ),
				'menu_name'          => $post_type_plural,
				'add_new'            => __( 'Add New ', $post_type_singular ),
				'add_new_item'       => __( 'Add New ' . $post_type_singular ),
				'edit_item'          => __( 'Edit ' . $post_type_singular ),
				'new_item'           => __( 'New ' . $post_type_singular ),
				'all_items'          => __( 'All ' . $post_type_plural ),
				'view_item'          => __( 'View ' . $post_type_singular ),
				'search_items'       => __( 'Search ' . $post_type_plural ),
			),
			'public'         => true,
			'description'    => 'Holds our '. $post_type_plural . ' and '. $post_type_singular . ' specific data',
    	'menu_position'  => 35,
      'menu_icon'      => 'dashicons-superhero',
    	'supports'       => array( 
				'title',  
			  'editor',  
				'thumbnail'   => false, 
				'excerpt'     => false,
				'comments'    => false,
			),
			'has_archive'    => false,
			'rewrite'        => array( 
        'slug'           => $post_type_slug,
        'with_front'     => true 
      ), 
		)
	);
}