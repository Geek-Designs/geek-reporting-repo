<?php
if (!defined('ABSPATH')) {
  exit;
}
add_action('vc_before_init', 'render_plugin_template_vc');

function render_plugin_template_vc() {
  $plugin_title                   = 'Plugin Template';
  $plugin_slug                    = 'plugin-template';
  $plugin_base                    = 'plugin_template';
  $core                           = 'geek-design';

  vc_map(array(
    'name'                        => __( $plugin_title, $core ),
    'base'                        => 'geek_'.$plugin_base,
    //"admin_enqueue_css"           => array(plugin_dir_url(__DIR__) . 'css/geek-custom-post-type-pagination-admin.css'),
    //"admin_enqueue_js"            => array(plugin_dir_url(__DIR__) . 'js/wpbakery-code.js'),
    'description'                 => __('', $core),
    "class"                       => "geek-wpb admin-geek-'.$plugin_slug.'",
    "is_container"                => false,
    'category'                    => __('Geek', $core),
    'icon'                        => "wpb-geek-'.$plugin_slug.'-icon wpb-geek-icon",
    'params'                      => array(
      /* ===== Settings ===== */
      array(
        'type'                    => 'dropdown',
        'class'                   => '',
        "edit_field_class"        => "vc_col-xs-12",
        'heading'                 => __('Type', $core),
        'param_name'              => 'type',
        'value'                   => array(
          __('Grid')              => 'grid',
          __('Masonry')           => 'masonry',
        ),
        'description'             => __('Select Type', $core),
        'admin_label'             => true,
        'weight'                  => 0,
        'group'                   => 'Settings',
      ),
      array(
        'type'                    => 'attach_images',
        'class'                   => '',
        "edit_field_class"        => "vc_col-xs-12",
        'heading'                 => __('Images', $core),
        'param_name'              => 'images',
        'value'                   => '',
        'description'             => __('Select Images', $core),
        'admin_label'             => true,
        'weight'                  => 0,
        'group'                   => 'Settings',
      ),
      array(
        "type"                    => "textarea_html",
        "heading"                 => __( "Content", $core ),
        "param_name"              => "content", // Important: Only one textarea_html param per content element allowed and it should have "content" as a "param_name"
        "value"                   => __( "<p>I am test text block. Click edit button to change this text.</p>", $core ),
        "group"                   => "Settings",
        "description"             => __( "Enter your content.", $core )
      ),
      array(
        'type'                    => 'dropdown',
        'class'                   => '',
        "edit_field_class"        => "vc_col-xs-12",
        'heading'                 => __('Columns', $core),
        'param_name'              => 'columns',
        'value'                   => array(
          __('1 Column')          => '1',
          __('2 Columns')         => '2',
          __('3 Columns')         => '3',
          __('4 Columns')         => '4',
          __('5 Columns')         => '5',
          __('6 Columns')         => '6',
        ),
        'description'             => __('Select Column Number', $core),
        'admin_label'             => true,
        'weight'                  => 0,
        'group'                   => 'Settings',
      ),
      /* ===== Design ===== */
      array( 
        'type'                    => 'textfield',
        'class'                   => '',
        "edit_field_class"        => "vc_col-xs-4",
        'heading'                 => __(' Width', $core),
        'param_name'              => 'width',
        'value'                   => '100%',
        'description'             => __(' Width', $core),
        'admin_label'             => false,
        'weight'                  => 0,
        'group'                   => 'Design',
      ),
      /* ===== Advanced ===== */
      array(
        "type"              => "textfield",
        "heading"           => __("Custom ID", $core),
        "param_name"        => "custom_id",
        "value"             => __("", $core),
        "description"       => __("Enter your custom ID (Must be unique). No Spaces", $core),
        "group"             => "Advanced",
      ),
      array(
        "type"              => "textfield",
        "heading"           => __("Custom Class", $core),
        "param_name"        => "custom_class",
        "value"             => __("", $core),
        "description"       => __("Enter any additional custom classes.", $core),
        "group"             => "Advanced",
      ),
    ),
  ));
}
/* ====== Functions ====== */